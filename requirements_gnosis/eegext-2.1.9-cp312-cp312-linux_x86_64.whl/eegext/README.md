## eegext_master

> author: Jiejian Luo
>
> email: luojiejian12@mails.ucas.ac.cn

### Data reader for NIHON KOHDEN electroencephalograph.

Support the models are listed as follow:

- EEG-1100A V01.00
- EEG-1100B V01.00
- EEG-1100C V01.00
- QI-403A   V01.00
- QI-403A   V02.00
- EEG-2100  V01.00
- EEG-2100  V02.00
- DAE-2100D V01.30
- DAE-2100D V02.00
- EEG-1200A V01.00

### usage

(1) for nihon:

```
from eegext.io.nihon import read_raw_nihon
raw = read_raw_nihon("Desktop/D1/NKT/EEG2100/DG0180X1.EEG")
raw.to_edf(file_path="happy.edf")
```

(2) for nicolet:

```
from eegext.io.nicolet import nicoletFile
from eegext.io.convert import write_raw_to_edf
nf = nicoletFile("Patient6_MONITOR2_t1_02212020112005/Pruned.e")
raw = nf.generate_raw()
write_raw_to_edf(raw, "Desktop/happy.edf")
```

(3) for compumedics (just for windows):

```
from eegext.io.compumedics import generate_raw
raw = generate_raw('20220319{7A9E80CC-02DE-429F-AB25-C774D471780F}.eeg/20220319{7A9E80CC-02DE-429F-AB25-C774D471780F}.sdy')
```

(4) for natus
```
from eegext.io.natus_reader import generate_raw
raw = generate_raw(path='\尼高力~ 测试_f364a29e-5a69-4687-bfc4-1dc1b6fe5726.erd', start_time=0, duartion=None, add_annot=True, preload=True)

# if load header only 
process_erd = generate_raw(ath='\尼高力~ 测试_f364a29e-5a69-4687-bfc4-1dc1b6fe5726.erd', start_time=0, duartion=None, add_annot=True, preload=False)

# if wanna duration time:
duration = process_erd.TimeDuration 

```