## Update logs
### v2.1.9 2026-07-30
modify bug of eegext.io.nicolet 

### v.2.1.8 2026-07-28
adapt python 3.12 

### v2.1.7 2026-05-20
modify natus bug 

### v2.1.6 2026-02-06
modify natus bug, add natus loader when preload=False 

### v2.1.5 2026-1-26
add natus reader 

### v.2.1.4 2025-10-13
modify eegext.io.nicolet to adjust all seeg channels and modify redstr for decode utf-16 problems

### v.2.1.3 2025-09-24
modify compumedics.py to adjust new mode channels set without montage

### v.2.1.2 2025-02-07

modify eegext.io.nicolet on segments data reading bug

### v.2.1.1 2024-12-05

fix the processing logic when eegext.io.nicolet on abnormal data

### v2.1.0 2024-11-20

fix bug of eegext.io.nicolet on channels reading and problem of raw.pick_channels and raw.get_data(picks=XX) channels inconsistent.

### v2.0.9 2024-06-14

add block reading function for nihon and compumedics.

### v2.0.8 2023-12-18

fix bug of eegext.io.nicolet

### v2.0.7 2023-02-24

fix bug of eegext.io.nihon.write_raw_to_edf

### v2.0.6 2022-07-06

modify io.compumedics.generate_raw parameter:path_base restrict from "XX/EEGData" to "XX/.sdy".

### v2.0.5 2022-05-25

fix io.nihon.read_raw_nihon ch_types problem
fix io.compumedics.generate_raw problem

### v2.0.4 2022-05-12

rearrage some files

### v2.0.3 2022-04-08

remove pyodbc from commpumedics.py
zhangqi

### v2.0.2 2022-03-30

fix positional argument problem when converting py to c

### v2.0.1 2022-01-05

fix write_raw_to_edf and make it adaptable to apollo loading

### v2.0.0 2021-12-31

new version, containing functions:

- io.nihon.read_raw_nihon
- io.convert.write_raw_to_edf
- io.nihon.read_21e
- io.nihon.read_metadata
- io.nihon.read_annotations
- io.nicolet.nicoletFile
- io.compumedics.generate_raw

io.nicolet.nicoletFile and io.compumedics.generate_raw are not stable.
Need many updates.
